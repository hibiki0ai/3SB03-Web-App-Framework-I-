<?php

namespace App\Http\Controllers;

use App\Models\lain;
use Illuminate\Http\Request;
use Mail;

class MailController extends Controller
{
    public function basic_email(){
        $data = array('name'=>"Tanachai");
        Mail::send(['text'=>'mail'],$data, function($message){
            $message->to('s5935512088@phuket.psu.ac.th','TA')->subject('Laravel Basic Testing Mail');
            $message->from('hibiki0ai@gmail.com','tanachai');
        });
        echo "Basis Email Sent.Check your inbox";
    }
}
