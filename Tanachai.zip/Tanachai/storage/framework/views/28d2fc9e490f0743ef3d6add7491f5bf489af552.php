<h1>Hi - TA</h1>
<p>Sending Mail from Laravel. </p>
<p>by Tanachai 6135512011</p><?php /**PATH C:\P61011\Tanachai\resources\views/mail.blade.php ENDPATH**/ ?>